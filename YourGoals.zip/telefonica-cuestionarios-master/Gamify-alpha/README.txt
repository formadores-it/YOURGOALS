OBTENER DATOS en JSON:

-Para obtener una lista de todos los roles: /data/roles
-Para obtener una lista de todos los usuarios: /data/usuarios
-Para obtener una lista de todos los usuarios de un rol concreto: /data/roles/{id}/usuarios
(rol admin: id=1, rol maestro: id=2, rol alumno: id=3)
-Para obtener una lista de todas las preguntas: data/preguntas
-Para obtener una lista de todas las categor�as: data/categorias
-Para obtener una lista de todas las preguntas de una categor�a: data/categorias/{id}/preguntas
-Para obtener una lista de todas las preguntas de un maestro concreto: data/usuarios/{id}/preguntas

MODIFICAR DATOS:

- Guardar un nuevo usuario: Enviar todos los datos de un Usuario con camelCase precedidos de "txt" a: /agregarUsuario
- Eliminar un usuario: /eliminarUsuario/{id}