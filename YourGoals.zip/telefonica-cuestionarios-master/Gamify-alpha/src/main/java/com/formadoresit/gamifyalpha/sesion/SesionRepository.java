package com.formadoresit.gamifyalpha.sesion;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="sesiones")
public interface SesionRepository extends CrudRepository<Sesion, Long>{
}
