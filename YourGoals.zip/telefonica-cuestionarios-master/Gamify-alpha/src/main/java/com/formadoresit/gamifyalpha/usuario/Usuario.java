package com.formadoresit.gamifyalpha.usuario;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.formadoresit.gamifyalpha.cuestionariorealizado.CuestionarioRealizado;
import com.formadoresit.gamifyalpha.pregunta.Pregunta;
import com.formadoresit.gamifyalpha.rol.Rol;
import com.formadoresit.gamifyalpha.sesion.Sesion;

@Entity
@JsonIgnoreProperties({"usuarios", "hibernateLazyInitializer", "handler"})
public class Usuario implements Serializable{

	private static final long serialVersionUID = 1L;

	//Atributos
	@Id
	@GeneratedValue
	private long Id;
	
	private String nombre;
	private String primerApellido;
	private String segundoApellido;
	private String urlImagen;
	private String pass;
	
	@Column(unique=true)
	private String email;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "id_rol")
	private Rol rol;
	
	@OneToMany(mappedBy="usuarioSesion", cascade=CascadeType.ALL)
	private List<Sesion> sesiones= new ArrayList<>();
	
	@OneToMany(mappedBy="usuarioCuestionario", cascade=CascadeType.ALL)
	private List<CuestionarioRealizado> cuestionarios= new ArrayList<>();
	
	@OneToMany(mappedBy="usuario", cascade=CascadeType.ALL)
	private List<Pregunta> preguntas= new ArrayList<>();
	

	//Constructores
	
	public Usuario(String email, String pass) {
		this.pass = pass;
		this.email = email;
	}
	public Usuario(){
		
	}
	//Getters y Setters
	public long getId() {
		return Id;
	}
	public void setId(long id) {
		this.Id = id;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getPrimerApellido() {
		return primerApellido;
	}
	public void setPrimerApellido(String primerApellido) {
		this.primerApellido = primerApellido;
	}
	public String getSegundoApellido() {
		return segundoApellido;
	}
	public void setSegundoApellido(String segundoApellido) {
		this.segundoApellido = segundoApellido;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Rol getRol() {
		return rol;
	}
	public void setRol(Rol rol) {
		this.rol = rol;
	}
	public String getUrlImagen() {
		return urlImagen;
	}
	public void setUrlImagen(String urlImagen) {
		this.urlImagen = urlImagen;
	}
	@Override
	public String toString() {
		return "Usuario [id=" + Id + ", nombre=" + nombre + ", primerApellido=" + primerApellido + ", segundoApellido="
				+ segundoApellido + ", urlImagen=" + urlImagen + ", pass=" + pass + ", email=" + email + ", rol=" + rol
				+ "]";
	}
	public List<Pregunta> getPreguntas() {
		return preguntas;
	}
	public void setPreguntas(List<Pregunta> preguntas) {
		this.preguntas = preguntas;
	}
	public List<Sesion> getSesiones() {
		return sesiones;
	}
	public void setSesiones(List<Sesion> sesiones) {
		this.sesiones = sesiones;
	}
}