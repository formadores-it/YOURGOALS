package com.formadoresit.gamifyalpha.pregunta;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="preguntas")
public interface PreguntaRepository extends CrudRepository<Pregunta, Long>{
	//TODO añadir servicios para obtener preguntas por id, idUsuario, idCuestionario e idCategoria
}
