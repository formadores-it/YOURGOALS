package com.formadoresit.gamifyalpha.usuario;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UsuarioController {

	@Autowired
	private UsuarioService usuarioService;
	
	@RequestMapping("/users")
	public List<Usuario> getAllUsuarios() {
		return usuarioService.getAllUsuarios();
	}
//	@RequestMapping(value = "/usuario/{id}")
//	public Usuario getUsuarioEnJson(@PathVariable long id) {
//		return usuarioService.getUsuario(id);
//	}
//	@RequestMapping("/listaUsuarios/rol={id}")
//	public @ResponseBody ArrayList<Usuario> usuariosRol(
//			@PathVariable long id){
//		ArrayList<Usuario> listaTotal= (ArrayList<Usuario>) usuarioService.getAllUsuariosByRolId(id);
//		return listaTotal;
//	}
//
	@RequestMapping(value = "/users", method = RequestMethod.POST)
	public void addUsuario(@RequestBody Usuario usuario) {
		usuarioService.addUsuario(usuario);
	}
	@RequestMapping(value = "/users/{id}", method = RequestMethod.PUT)
	public void updateUsuario(@RequestBody Usuario usuario, @PathVariable Long id) {
		usuarioService.updateUsuario(id, usuario);
	}
	@RequestMapping(value = "/users/{id}", method = RequestMethod.DELETE)
	public void deleteUsuario(@PathVariable Long id) {
		usuarioService.removeUsuario(id);
	}
}