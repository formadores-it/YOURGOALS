package com.formadoresit.gamifyalpha.usuario;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.ResponseBody;

import com.formadoresit.gamifyalpha.rol.Rol;

@RepositoryRestResource(path="usuarios")
public interface UsuarioRepository extends CrudRepository<Usuario, Long>{
	public @ResponseBody List<Usuario> findByNombre(@Param(value = "nombre") String nombre);
	public List<Usuario> findByRol(Rol rol);
	public List<Usuario> findByNombreAndPass(String nombre, String password);
	public List<Usuario> findByEmailAndPass(String email, String pass);
	public List<Usuario> findByRolId(long id);
}