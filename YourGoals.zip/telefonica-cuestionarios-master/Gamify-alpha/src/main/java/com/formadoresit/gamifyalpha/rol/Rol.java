package com.formadoresit.gamifyalpha.rol;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.formadoresit.gamifyalpha.usuario.Usuario;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Rol implements Serializable{

	private static final long serialVersionUID = 1L;
	
	//Atributos
	public static final long ROL_ADMIN = 1L;
	public static final long ROL_MAESTRO = 2L;
	public static final long ROL_ALUMNO = 3L;

	
	@Id
	@GeneratedValue
	private long id;
	private String nombre;
	//@JsonManagedReference		Esto servía para evitar bidireccionalidades en bucle, pero ahora se arregla con el JsonIgnore
	@JsonIgnore
	@OneToMany(mappedBy="rol", cascade=CascadeType.ALL)
	private List<Usuario> usuarios= new ArrayList<>();
	
	public List<Usuario> getUsuarios() {
		return usuarios;
	}
	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}
	public Rol(){
	}
	public Rol(String nombre) {
		this.nombre = nombre;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	@Override
	public String toString() {
		return "Rol [id=" + id + ", nombre=" + nombre + ", usuarios=" + usuarios + "]";
	}
}
