package com.formadoresit.gamifyalpha.rol;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="roles")
public interface RolRepository extends CrudRepository<Rol, Long>{
	
}
