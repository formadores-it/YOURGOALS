package com.formadoresit.gamifyalpha.sesion;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.formadoresit.gamifyalpha.usuario.Usuario;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Sesion implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private long Id;
	
	private Date fechaHoraInicio;
	private Date fechaHoraCierre;
	

	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade=CascadeType.ALL)
	@JoinColumn(name = "id_usuario")
	private Usuario usuarioSesion;
	
	//Constructores
	public Sesion(){
		
	}
	//Getters y setters

	public long getId() {
		return Id;
	}
	public void setId(long id) {
		Id = id;
	}

	public Usuario getUsuarioSesion() {
		return usuarioSesion;
	}

	public void setUsuarioSesion(Usuario usuarioSesion) {
		this.usuarioSesion = usuarioSesion;
	}

	@Override
	public String toString() {
		return "Sesion [Id=" + Id + ", fechaHoraInicio=" + fechaHoraInicio + ", fechaHoraCierre=" + fechaHoraCierre
				+ "]";
	}

	public Date getFechaHoraInicio() {
		return fechaHoraInicio;
	}

	public void setFechaHoraInicio(Date fechaHoraInicio) {
		this.fechaHoraInicio = fechaHoraInicio;
	}

	public Date getFechaHoraCierre() {
		return fechaHoraCierre;
	}

	public void setFechaHoraCierre(Date fechaHoraCierre) {
		this.fechaHoraCierre = fechaHoraCierre;
	}

	
}

