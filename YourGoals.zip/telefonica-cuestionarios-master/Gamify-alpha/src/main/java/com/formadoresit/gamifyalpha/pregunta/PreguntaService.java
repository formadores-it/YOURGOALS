package com.formadoresit.gamifyalpha.pregunta;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PreguntaService {
	@Autowired
	private PreguntaRepository preguntaRepository;
	//TODO añadir métodos CRUD
}
