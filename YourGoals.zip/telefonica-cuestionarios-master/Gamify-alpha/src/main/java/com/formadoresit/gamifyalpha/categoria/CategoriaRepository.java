package com.formadoresit.gamifyalpha.categoria;
 
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="categorias")
public interface CategoriaRepository extends CrudRepository<Categoria, Long>{
}