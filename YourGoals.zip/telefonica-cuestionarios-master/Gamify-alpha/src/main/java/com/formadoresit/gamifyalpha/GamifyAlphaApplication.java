package com.formadoresit.gamifyalpha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GamifyAlphaApplication {
	
	//Main que ejecuta la aplicación Spring Boot
	public static void main(String[] args) {
		SpringApplication.run(GamifyAlphaApplication.class, args);
	}
}
