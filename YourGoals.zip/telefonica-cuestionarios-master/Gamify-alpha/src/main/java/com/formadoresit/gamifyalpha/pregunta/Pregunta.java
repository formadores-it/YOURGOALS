package com.formadoresit.gamifyalpha.pregunta;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.formadoresit.gamifyalpha.categoria.Categoria;
import com.formadoresit.gamifyalpha.cuestionario.Cuestionario;
import com.formadoresit.gamifyalpha.rol.Rol;
import com.formadoresit.gamifyalpha.usuario.Usuario;

@Entity
public class Pregunta implements Serializable{

	private static final long serialVersionUID = 1L;
	
	//Atributos
	@Id
	@GeneratedValue
	private long Id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_categoria")
	private Categoria categoria;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_maestro")
	private Usuario usuario;
	
	private String pregunta;
	private String respuestaVerdadera;
	private String respuestaFalsaUno;
	private String respuestaFalsaDos;
	private String url;
	
//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "id_cuestionario")
//	private Cuestionario cuestionario;
//	
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "cuestionarios_con_preguntas",
		joinColumns={@JoinColumn(name="idPreguntas")},
		inverseJoinColumns={@JoinColumn(name="idCuestionarios")})
	private List<Cuestionario> cuestionarios;
	
	//Getters y Setters
	public long getId() {
		return Id;
	}
	public void setId(long id) {
		this.Id = id;
	}
	public String getPregunta() {
		return pregunta;
	}
	public void setPregunta(String pregunta) {
		this.pregunta = pregunta;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Categoria getCategoria() {
		return categoria;
	}
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	public String getRespuestaVerdadera() {
		return respuestaVerdadera;
	}
	public void setRespuestaVerdadera(String respuestaVerdadera) {
		this.respuestaVerdadera = respuestaVerdadera;
	}
	public String getRespuestaFalsaUno() {
		return respuestaFalsaUno;
	}
	public void setRespuestaFalsaUno(String respuestaFalsaUno) {
		this.respuestaFalsaUno = respuestaFalsaUno;
	}
	public String getRespuestaFalsaDos() {
		return respuestaFalsaDos;
	}
	public void setRespuestaFalsaDos(String respuestaFalsaDos) {
		this.respuestaFalsaDos = respuestaFalsaDos;
	}
	@Override
	public String toString() {
		return "Pregunta [id=" + Id + ", usuario=" + usuario + ", categoria=" + categoria + ", pregunta=" + pregunta
				+ ", respuestaVerdadera=" + respuestaVerdadera + ", respuestaFalsaUno=" + respuestaFalsaUno
				+ ", respuestaFalsaDos=" + respuestaFalsaDos + ", url=" + url + "]";
	}
//	public Cuestionario getCuestionario() {
//		return cuestionario;
//	}
//	public void setCuestionario(Cuestionario cuestionario) {
//		this.cuestionario = cuestionario;
//	}
	public List<Cuestionario> getCuestionarios() {
		return cuestionarios;
	}
	public void setCuestionarios(List<Cuestionario> cuestionarios) {
		this.cuestionarios = cuestionarios;
	}
	
}
