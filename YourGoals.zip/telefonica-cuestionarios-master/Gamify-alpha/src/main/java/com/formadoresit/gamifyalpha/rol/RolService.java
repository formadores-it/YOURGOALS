package com.formadoresit.gamifyalpha.rol;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RolService {
	@Autowired
	private RolRepository rolRepository;
	
	public List<Rol> getAllRoles(){
		List<Rol> roles = new ArrayList<>();
		rolRepository.findAll().forEach(roles::add);
		return roles;
	}
	public Rol getRol(long id){
		return rolRepository.findOne(id);
	}
	public void addRol(Rol Rol){
		rolRepository.save(Rol);
	}
	public void updateRol(long id, Rol Rol){
		rolRepository.save(Rol);
	}
	public void removeRol(long id){
		rolRepository.delete(id);
	}
}
