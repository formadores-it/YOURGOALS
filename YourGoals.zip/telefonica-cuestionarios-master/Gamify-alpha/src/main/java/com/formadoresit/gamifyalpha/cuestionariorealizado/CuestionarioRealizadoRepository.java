package com.formadoresit.gamifyalpha.cuestionariorealizado;

import org.springframework.data.repository.CrudRepository;

import com.formadoresit.gamifyalpha.sesion.Sesion;

public interface CuestionarioRealizadoRepository extends CrudRepository<CuestionarioRealizado, Long>{

}
