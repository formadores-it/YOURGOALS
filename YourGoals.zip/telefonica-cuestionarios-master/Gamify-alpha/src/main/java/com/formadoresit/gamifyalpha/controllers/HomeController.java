package com.formadoresit.gamifyalpha.controllers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.formadoresit.gamifyalpha.categoria.Categoria;
import com.formadoresit.gamifyalpha.categoria.CategoriaRepository;
import com.formadoresit.gamifyalpha.cuestionario.Cuestionario;
import com.formadoresit.gamifyalpha.cuestionario.CuestionarioRepository;
import com.formadoresit.gamifyalpha.pregunta.Pregunta;
import com.formadoresit.gamifyalpha.pregunta.PreguntaRepository;
import com.formadoresit.gamifyalpha.rol.Rol;
import com.formadoresit.gamifyalpha.rol.RolRepository;
import com.formadoresit.gamifyalpha.sesion.Sesion;
import com.formadoresit.gamifyalpha.sesion.SesionRepository;
import com.formadoresit.gamifyalpha.usuario.Usuario;
import com.formadoresit.gamifyalpha.usuario.UsuarioRepository;


@Controller
public class HomeController {
	//Ojo! si una vista tiene alguna referencia a un campo vacío, por ejemplo href="", el navegador generará varias peticiones al servidor!

	//Atributos
	private String url;		//Página url que guarda dónde se encuentra el usuario en todo momento
	@Autowired
	private HttpSession session;	//Atributo Session para obtener atributos de la sesión
	@Autowired
	private UsuarioRepository usuarioRepos;	//Atributo para manejar repositorios de usuarios
	@Autowired
	private RolRepository rolesRepos;	//Atributo para manejar repositorios de roles
	@Autowired
	private CategoriaRepository categoriaRepos;	//Atributo para manejar repositorios de categorias
	@Autowired
	private SesionRepository sesionesRepos;	//Atributo para manejar repositorios de preguntas
	@Autowired
	private PreguntaRepository preguntaRepos;	//Atributo para manejar repositorios de preguntas
	@Autowired
	private CuestionarioRepository cuestionarioRepos;	//Atributo para manejar repositorios de preguntas
	//Mappings
	@RequestMapping("/")	//Al arrancar la página va al Landing.jsp
	public ModelAndView landing(){
		ModelAndView mav = new ModelAndView();
		url = "/landing";
		session.setAttribute("url", url);
		mav.setViewName(url);
		return mav;
	}
	//Al introducir tus datos los procesa y redirige según seas Admin, Maestro o Alumno
	@RequestMapping(value="validar")
	public ModelAndView validar(
			@RequestParam("txtEmail") String email,
			@RequestParam("txtPassword") String pass){
		//Hemos recogido del login inicial el email y password

		//Creamos un modelo vista controlador
		ModelAndView mav = new ModelAndView();
		//Creamos una lista de usuarios que coinciden con ese Email y ese Pass (Como los emails son claves únicas, sólo debería aparecer un usuario en esa lista, o ninguno)
		List<Usuario> usuarios = usuarioRepos.findByEmailAndPass(email, pass);
		//Si la lista no está vacía significa que ese usuario y ese pass existen
		if (!usuarios.isEmpty()){
			Usuario usuarioConectado = usuarios.get(0);	//Cogemos el primer elemento de la lista (el usuario conectado)
			Sesion nuevaSesion = new Sesion();
			nuevaSesion.setFechaHoraInicio(new Date());
			System.out.println(nuevaSesion);
			nuevaSesion.setUsuarioSesion(usuarioConectado);
			sesionesRepos.save(nuevaSesion);
			
			session.setAttribute("session", nuevaSesion); //Introducimos el usuario encontrado en la sesión
			session.setAttribute("usuarioSession", usuarioConectado); //Introducimos el usuario encontrado en la sesión
			//Dependiendo de su rol, lo dirigimos a admin.jsp, maestro.jsp o alumno.jsp
			if (usuarioConectado.getRol().getId()==Rol.ROL_ADMIN){
				mav.setViewName("admin");
			}
			if (usuarioConectado.getRol().getId()==Rol.ROL_MAESTRO){
				mav.setViewName("maestro");
			}
			if (usuarioConectado.getRol().getId()==Rol.ROL_ALUMNO){
				mav.setViewName("alumno");
			}
		} else //Si la lista está vacía significa que no existe ese usuario
		{
			//introducimos un mensaje de error y lo pasamos por el mav
			mav.addObject("mensajeError", "Email y/o contraseña no válidos");
			//redirigimos a la página de registro
			mav.setViewName("landing");
		}
		//Devolvemos el mav
		return mav;
	}
	@RequestMapping("/altaAlumnos")
	public String altaAlumnos(){
		return "altaAlumnos";
	}

	@RequestMapping("/crearPregunta")
	public ModelAndView crearPregunta(){
		ModelAndView mav = new ModelAndView();
		url = "/crearPregunta";
		session.setAttribute("url", url);
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/admin")
	public ModelAndView admin(){
		ModelAndView mav = new ModelAndView();
		url = "/admin";
		session.setAttribute("url", url);
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/alumno")
	public ModelAndView alumno(){
		ModelAndView mav = new ModelAndView();
		url = "/alumno";
		session.setAttribute("url", url);
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/maestro")
	public ModelAndView maestro(){
		ModelAndView mav = new ModelAndView();
		url = "/maestro";
		session.setAttribute("url", url);
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/crearCuestionario")
	public ModelAndView crearCuestionario(){
		ModelAndView mav = new ModelAndView();
		url = "/crearCuestionario";
		session.setAttribute("url", url);
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/panelControl")
	public String panelControl(){
		return "panelControl";
	}
	@RequestMapping("/altaMaestros")
	public String altaMaestros(){
		return "altaMaestros";
	}
	@RequestMapping("/pregunta{idCuest}")
	public ModelAndView pregunta(
			@PathVariable("idCuest") String id,
			@SessionAttribute("url") String url){
		session.setAttribute("idCuest", id);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("pregunta");
		return mav;
	}
	@RequestMapping("/logout")
	public String logout(){
		Sesion sesionActual = (Sesion) session.getAttribute("session");
		sesionActual.setFechaHoraCierre(new Date());
		sesionesRepos.save(sesionActual);
		session.invalidate();
		return "landing";
	}
	@RequestMapping("/listaMaestros")
	public ModelAndView listaMaestros(){
		ModelAndView mav = new ModelAndView();
		url = "/listaMaestros";
		session.setAttribute("url", url);
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping("/listaAlumnos")
	public ModelAndView listaAlumnos(){
		ModelAndView mav = new ModelAndView();
		url = "/listaAlumnos";
		session.setAttribute("url", url);
		mav.setViewName(url);
		return mav;
	}

	@RequestMapping("/listaCuestionarios")
	public ModelAndView listaCuestionarios(){
		ModelAndView mav = new ModelAndView();
		url = "/listaCuestionarios";
		session.setAttribute("url", url);
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping("/listaCuestionariosAlumno")
	public ModelAndView listaCuestionariosAlumno(){
		ModelAndView mav = new ModelAndView();
		url = "/listaCuestionariosAlumno";
		session.setAttribute("url", url);
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/nuevoCuestionario")
	public ModelAndView nuevoCuestionario(){
		ModelAndView mav = new ModelAndView();
		url = "/nuevoCuestionario";
		session.setAttribute("url", url);
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/eliminarUsuario/{id}")
	public ModelAndView eliminarUsuario(
			@PathVariable long id,
			@SessionAttribute("url") String url){
		usuarioRepos.delete(id);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:" +url);
		return mav;
	}
	@RequestMapping("/agregarUsuario")
	public ModelAndView agregarUsuario(
			@SessionAttribute("url") String url,
			@RequestParam("txtEmail") String email,
			@RequestParam("txtPass") String pass,
			@RequestParam("txtNombre") String nombre,
			@RequestParam("txtPrimerApellido") String primerApellido,
			@RequestParam("txtSegundoApellido") String segundoApellido,
			@RequestParam("txtUrlImagen") String urlImagen,
			@RequestParam("txtRol") long rol){
		Usuario nuevoUsuario = new Usuario();
		nuevoUsuario.setEmail(email);
		nuevoUsuario.setNombre(nombre);
		nuevoUsuario.setPass(pass);
		nuevoUsuario.setPrimerApellido(primerApellido);
		nuevoUsuario.setSegundoApellido(segundoApellido);
		nuevoUsuario.setUrlImagen(urlImagen);
		Rol rolNuevo = rolesRepos.findOne(rol);
		nuevoUsuario.setRol(rolNuevo);
		usuarioRepos.save(nuevoUsuario);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/modificarUsuario")
	public ModelAndView modificarUsuario(
			@SessionAttribute("url") String url,
			@RequestParam("txtId") long id,
			@RequestParam("txtEmail") String email,
			@RequestParam("txtPass") String pass,
			@RequestParam("txtNombre") String nombre,
			@RequestParam("txtPrimerApellido") String primerApellido,
			@RequestParam("txtSegundoApellido") String segundoApellido,
			@RequestParam("txtUrlImagen") String urlImagen,
			@RequestParam("txtRol") long rol){
		Usuario nuevoUsuario = usuarioRepos.findOne(id);
		nuevoUsuario.setEmail(email);
		nuevoUsuario.setNombre(nombre);
		nuevoUsuario.setPass(pass);
		nuevoUsuario.setPrimerApellido(primerApellido);
		nuevoUsuario.setSegundoApellido(segundoApellido);
		nuevoUsuario.setUrlImagen(urlImagen);
		Rol rolNuevo = rolesRepos.findOne(rol);
		nuevoUsuario.setRol(rolNuevo);
		usuarioRepos.save(nuevoUsuario);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/agregarPregunta")
	public ModelAndView agregarPregunta(
			@RequestParam("txtCategoria") long id,
			@RequestParam("txtPregunta") String pregunta,
			@RequestParam("txtRespuestaVerdadera") String respuestaVerdadera,
			@RequestParam("txtRespuestaFalsaUno") String respuestaFalsaUno,
			@RequestParam("txtRespuestaFalsaDos") String respuestaFalsaDos,
			@RequestParam("txtUrlImagen") String imagenUrl,
			@SessionAttribute("url") String url,
			@SessionAttribute("usuarioSession") Usuario usuario			
			){
		Pregunta nuevaPregunta = new Pregunta();
		nuevaPregunta.setPregunta(pregunta);
		nuevaPregunta.setRespuestaVerdadera(respuestaVerdadera);
		nuevaPregunta.setRespuestaFalsaUno(respuestaFalsaUno);
		nuevaPregunta.setRespuestaFalsaDos(respuestaFalsaDos);
		nuevaPregunta.setUrl(imagenUrl);
		Categoria categoriaNueva = categoriaRepos.findOne(id);
		nuevaPregunta.setCategoria(categoriaNueva);
		nuevaPregunta.setUsuario(usuario);
		preguntaRepos.save(nuevaPregunta);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/modificarPregunta")
	public ModelAndView modificarPregunta(
			@RequestParam("txtCategoria") long id,
			@RequestParam("txtId") long idpreg,
			@RequestParam("txtPregunta") String pregunta,
			@RequestParam("txtRespuestaVerdadera") String respuestaVerdadera,
			@RequestParam("txtRespuestaFalsaUno") String respuestaFalsaUno,
			@RequestParam("txtRespuestaFalsaDos") String respuestaFalsaDos,
			@SessionAttribute("url") String url,
			@SessionAttribute("usuarioSession") Usuario usuario			
			){
		Pregunta nuevaPregunta = preguntaRepos.findOne(idpreg);
		nuevaPregunta.setPregunta(pregunta);
		nuevaPregunta.setRespuestaVerdadera(respuestaVerdadera);
		nuevaPregunta.setRespuestaFalsaUno(respuestaFalsaUno);
		nuevaPregunta.setRespuestaFalsaDos(respuestaFalsaDos);
		nuevaPregunta.setUrl(url);
		Categoria categoriaNueva = categoriaRepos.findOne(id);
		nuevaPregunta.setCategoria(categoriaNueva);
		nuevaPregunta.setUsuario(usuario);
		preguntaRepos.save(nuevaPregunta);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/eliminarPregunta/{id}")
	public ModelAndView eliminarPregunta(
			@PathVariable long id,
			@SessionAttribute("url") String url){
		preguntaRepos.delete(id);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:" +url);
		return mav;
	}
	@RequestMapping("/agregarCategoria")
	public ModelAndView agregarCategoria(
			@RequestParam("txtNombre") String nombre,
			@SessionAttribute("url") String url,
			@SessionAttribute("usuarioSession") Usuario usuario			
			){
		Categoria nuevaCategoria = new Categoria();
		nuevaCategoria.setNombre(nombre);
		categoriaRepos.save(nuevaCategoria);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/agregarCuestionario")
	public ModelAndView agregarCuestionario(
			@RequestParam("txtNombre") String nombre
			){
		Cuestionario nuevoCuestionario = new Cuestionario();
		nuevoCuestionario.setNombre(nombre);
		cuestionarioRepos.save(nuevoCuestionario);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(url);
		return mav;
	}

	@RequestMapping("/modificarCategoria")
	public ModelAndView modificarCategoria(
			@RequestParam("txtNombre") String nombre,
			@RequestParam("txtId") long id,
			@SessionAttribute("url") String url,
			@SessionAttribute("usuarioSession") Usuario usuario			
			){
		Categoria nuevaCategoria = categoriaRepos.findOne(id);
		nuevaCategoria.setNombre(nombre);
		categoriaRepos.save(nuevaCategoria);
		ModelAndView mav = new ModelAndView();
		mav.setViewName(url);
		return mav;
	}
	@RequestMapping("/eliminarCategoria/{id}")
	public ModelAndView eliminarCategoria(
			@PathVariable long id,
			@SessionAttribute("url") String url){
		categoriaRepos.delete(id);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:" +url);
		return mav;
	}
	@RequestMapping("/nuevaPreguntaParaCuestionario{id}")
    public ModelAndView nuevaPreguntaParaCuestionario(
            @PathVariable("id") long idC
            ){
        ModelAndView mav = new ModelAndView();
        url = "nuevoCuestionario";
        session.setAttribute("idCuestionario", idC);
        mav.setViewName(url);
        return mav;
    }
	@RequestMapping("/eliminarCuestionario{id}")
    public ModelAndView eliminarCuestionario(
            @PathVariable long id,
            @SessionAttribute("url") String url){
        cuestionarioRepos.delete(id);
        ModelAndView mav = new ModelAndView();
        mav.setViewName("redirect:" +url);
        return mav;
    }
	@RequestMapping("/cuestionariosRealizados")
    public ModelAndView cuestionariosRealizados(){
        ModelAndView mav = new ModelAndView();
        url = "/alumno";
        session.setAttribute("url", url);
        mav.setViewName(url);
        return mav;
    }
	@RequestMapping("/preguntaParaCuestionario")
    public ModelAndView agregarCuestionario(
            @RequestParam("txtIdCuestionario") long idC,
            @RequestParam("txtIdPregunta") long idP
            ){
	Cuestionario nuevoCues = cuestionarioRepos.findOne(idC);
	nuevoCues.getPreguntas().add(preguntaRepos.findOne(idP));
	cuestionarioRepos.save(nuevoCues);

//        List<Pregunta> lista = nuevoCuestionario.getListaPreguntas();
//        lista.add(preguntaRepos.findOne(idP));
//        cuestionarioRepos.save(nuevoCuestionario);
//        Pregunta pregunta = preguntaRepos.findOne(idP);
//        pregunta.setCuestionario(nuevoCuestionario);
//        preguntaRepos.save(pregunta);
        ModelAndView mav = new ModelAndView();
        mav.setViewName(url);
        return mav;
    }
}

