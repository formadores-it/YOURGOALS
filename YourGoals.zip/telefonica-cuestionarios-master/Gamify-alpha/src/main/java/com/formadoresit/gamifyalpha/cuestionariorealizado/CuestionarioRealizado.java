package com.formadoresit.gamifyalpha.cuestionariorealizado;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.formadoresit.gamifyalpha.usuario.Usuario;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class CuestionarioRealizado implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private long Id;

	private String preguntasRespuestas;
	private Date fechaHora;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_usuario")
	private Usuario usuarioCuestionario;

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public String getPreguntasRespuestas() {
		return preguntasRespuestas;
	}

	public void setPreguntasRespuestas(String preguntasRespuestas) {
		this.preguntasRespuestas = preguntasRespuestas;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Usuario getUsuarioCuestionario() {
		return usuarioCuestionario;
	}

	public void setUsuarioCuestionario(Usuario usuarioCuestionario) {
		this.usuarioCuestionario = usuarioCuestionario;
	}
}
