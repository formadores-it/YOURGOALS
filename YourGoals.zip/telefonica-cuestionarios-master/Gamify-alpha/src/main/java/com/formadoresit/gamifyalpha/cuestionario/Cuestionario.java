package com.formadoresit.gamifyalpha.cuestionario;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.formadoresit.gamifyalpha.pregunta.Pregunta;
import com.formadoresit.gamifyalpha.rol.Rol;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Cuestionario implements Serializable{

	private static final long serialVersionUID = 1L;
	
	
	@Id
	@GeneratedValue
	private long Id;
	private String nombre;


//	@OneToMany(mappedBy="cuestionario")
//	private List<Pregunta> listaPreguntas;
	
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "cuestionarios_con_preguntas",
		joinColumns={@JoinColumn(name="idCuestionarios")},
		inverseJoinColumns={@JoinColumn(name="idPreguntas")})
	private List<Pregunta> preguntas;
	
	
	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

//	public List<Pregunta> getListaPreguntas() {
//		return listaPreguntas;
//	}
//
//	public void setListaPreguntas(List<Pregunta> listaPreguntas) {
//		this.listaPreguntas = listaPreguntas;
//	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Pregunta> getPreguntas() {
		return preguntas;
	}

	public void setPreguntas(List<Pregunta> preguntas) {
		this.preguntas = preguntas;
	}
	

}
