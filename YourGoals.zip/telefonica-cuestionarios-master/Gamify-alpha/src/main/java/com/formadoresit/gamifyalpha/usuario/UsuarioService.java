package com.formadoresit.gamifyalpha.usuario;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.formadoresit.gamifyalpha.rol.Rol;

@Service
public class UsuarioService {
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	public List<Usuario> getAllUsuarios(){
		List<Usuario> usuarios = new ArrayList<>();
		usuarioRepository.findAll().forEach(usuarios::add);
		return usuarios;
	}
	public List<Usuario> getAllUsuariosByRol(Rol rol){
		List<Usuario> usuarios = new ArrayList<>();
		usuarioRepository.findByRol(rol).forEach(usuarios::add);
		return usuarios;
	}
	public List<Usuario> getAllUsuariosByRolId(long id){
		List<Usuario> usuarios = new ArrayList<>();
		usuarioRepository.findByRolId(id).forEach(usuarios::add);
		return usuarios;
	}
	public List<Usuario> getUsuariosByNombreAndPass(String nombre, String pass){
		List<Usuario> usuarios = new ArrayList<>();
		usuarioRepository.findByNombreAndPass(nombre, pass)
		.forEach(usuarios::add);
		return usuarios;
	}
	public List<Usuario> getUsuariosByEmailAndPass(String email, String pass){
		List<Usuario> usuarios = new ArrayList<>();
		usuarioRepository.findByEmailAndPass(email, pass)
		.forEach(usuarios::add);
		return usuarios;
	}
	public Usuario getOneUsuarioByEmailAndPass(String email, String pass){
		List<Usuario> usuarios = new ArrayList<>();
		usuarioRepository.findByEmailAndPass(email, pass);
		Usuario usuario = usuarios.get(0);
		return usuario;
	}
	public Usuario getUsuario(long id){
		return usuarioRepository.findOne(id);
	}
	public void addUsuario(Usuario usuario){
		usuarioRepository.save(usuario);
	}
	public void updateUsuario(long id, Usuario usuario){
		usuarioRepository.save(usuario);
	}
	public void removeUsuario(long id){
		usuarioRepository.delete(id);
	}
}
