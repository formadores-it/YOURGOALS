package com.formadoresit.gamifyalpha.pregunta;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class PreguntaController {

}
