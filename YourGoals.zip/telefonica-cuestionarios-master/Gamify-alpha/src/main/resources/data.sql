-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: gamify
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `rol`
--

LOCK TABLES `rol` WRITE;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` VALUES (1,'admin'),(2,'maestro'),(3,'alumno');
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'mates'),(2,'ciencias'),(3,'lengua'),(4,'java'),(5,'entretenimiento'),(6,'Geografía');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'admin@gmail.com','Juan','admin',NULL,NULL,NULL,1),(2,'maestro@gmail.com','Pedro','maestro','Lopez','Lasa','',2),(3,'roque@gmail.com','Roque','roque','Carmona','Luque',NULL,3),(4,'erik@gmail.com','Erik Heidegger','erik','Sanches','Martins','',3),(5,'maria@gmail.com','María D.','maria','Goris','Cabezas','',3),(6,'adri@gmail.com','Adrián','adri','Alameda','Morcillo','',3),(7,'salva@gmail.com','Salva','salva','Llorca','Frances','',2),(8,'diego@gmail.com','Diego','diego','Jimenez','Recio','',2),(9,'mariabeta@gmail.com','María','beta','Landa','Beta','',2),(10,'francisca@gmail.com','Francisca','francisca','Sanchez','Shyamalan','',2),(11,'juanlu@gmail.com','Juan Luis ','12345','Rodriguez','','',2),(12,'juandi@gmail.com','Juan Diego','12345','Dominguez','','',2),(14,'miguel@gmail.com','Miguel','12345','Sanchez','Yuste','',3),(15,'cristian@gmail.com','Crisrian','12345','Sanchez','Escudero','',3),(16,'johanna@gmail.com','Johanna','12345','Goris','Cuenca','',3),(17,'salvador@gmail.com','Salvador','12345','Exprime','Android','',3),(18,'jorge@gmail.com','Jorge','12345','Fernández','Díaz','',2),(19,'albertocabeza@gmail.com','Alberto','12345','Carmona','Cabeza','',2),(20,'gutiii@gmail.com','Jesus','12345','Gutierrez','Luque','',2),(21,'anaanton@gmail.com','Ana','12345','Antón','Lemieux','',3),(22,'isarios@gmail.com','Isabel','12345','Luque','Ríos','',3);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Dumping data for table `pregunta`
--

LOCK TABLES `pregunta` WRITE;
/*!40000 ALTER TABLE `pregunta` DISABLE KEYS */;
INSERT INTO `pregunta` VALUES (1,'2+2?','2','22','4',NULL,1,2),(2,'qué hace un equals?','nada','poco','mucho',NULL,4,2),(3,'3x25?','49','34','75',NULL,1,2),(4,'me estáis escuchando?','sí','mmm, sí','...',NULL,4,7),(5,'¿Cuál es la red social que se llama caralibro?','whatsapp','tuenti','FaceBook','',5,1),(6,'¿Cual era la red social que murió para transformarse en una compañía móvil?','fotolog','mySpace','tuenti','',5,1),(7,'¿Cuál es el icono de twitter?','un limón','un pepino','un pajarico','',5,1);
/*!40000 ALTER TABLE `pregunta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `cuestionario`
--

LOCK TABLES `cuestionario` WRITE;
/*!40000 ALTER TABLE `cuestionario` DISABLE KEYS */;
INSERT INTO `cuestionario` VALUES (2,'Matematicas'),(3,'Ingles'),(4,'Biología'),(5,'Cuestionario de Java de Salva'),(6,'Redes Sociales');
/*!40000 ALTER TABLE `cuestionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `cuestionario_realizado`
--

LOCK TABLES `cuestionario_realizado` WRITE;
/*!40000 ALTER TABLE `cuestionario_realizado` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuestionario_realizado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `cuestionarios_con_preguntas`
--

LOCK TABLES `cuestionarios_con_preguntas` WRITE;
/*!40000 ALTER TABLE `cuestionarios_con_preguntas` DISABLE KEYS */;
INSERT INTO `cuestionarios_con_preguntas` VALUES (5,3),(5,4),(5,2),(4,1),(4,2),(6,7),(6,6),(6,5),(6,4);
/*!40000 ALTER TABLE `cuestionarios_con_preguntas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `sesion`
--

LOCK TABLES `sesion` WRITE;
/*!40000 ALTER TABLE `sesion` DISABLE KEYS */;
INSERT INTO `sesion` VALUES (1,'2017-03-16 09:20:22','2017-03-16 09:10:11',1),(2,'2017-03-16 09:20:44','2017-03-16 09:20:30',17),(3,'2017-03-16 09:28:53','2017-03-16 09:26:31',17),(4,'2017-03-16 09:35:15','2017-03-16 09:34:40',1),(7,'2017-03-16 10:48:45','2017-03-16 10:48:02',1),(8,NULL,'2017-03-16 10:48:56',1),(9,'2017-03-16 12:28:10','2017-03-16 12:15:32',1);
/*!40000 ALTER TABLE `sesion` ENABLE KEYS */;
UNLOCK TABLES;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-16 12:35:24
