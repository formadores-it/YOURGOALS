/**
 * 
 */

angular
.module("appcategorias",[]) //creamos el modulo llamado app
.controller("appcategorias",["$http", miControlador]); //creamos el controlador 'micontrolador', y le pasamos un array con el $http
//y la función mi controlador



function miControlador($http){ //creamos la función de miControlador pasandole el $http(Esto sirve para que se realicen comunicaciones entre servidores a través de Ajax)
	var vm = this; //esto lo ponemos siempre
	vm.listaCategorias = []; //declaramos un array llamado listaUsuarios por ejemplo
	vm.cargarCategorias= function(){
		// creamos la función que hará la consulta y la dividimos en dos funciones principales
		var exito = function(resp){ //en esta metemos lo que hará la app si la consulta ha sido realizada correctamente
			vm.listaCategorias = resp.data._embedded.categorias; 
		};
		var error = function(){ // si ha habido un erroe en la consulta se ejecutaria esta función 
			alert("Ha habido un error en la consulta");
		};

		$http.get("/data/categorias").then(exito, error); //aquí se ponen los datos de la consulta, osea la url
		//y en el orden que aparece .then(funcionDeExito,funciónDeError)

	};
	vm.cargarCategorias();
	
}