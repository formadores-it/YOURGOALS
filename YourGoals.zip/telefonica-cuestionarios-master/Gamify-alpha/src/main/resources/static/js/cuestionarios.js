/**
 * 
 */

var app = angular.module("app",[]);
app.controller("appcuestionarios",["$http", miControlador]); //creamos el controlador 'micontrolador', y le pasamos un array con el $http
app.controller("appcuestionarios2",["$http", miControlador2]); //creamos el controlador 'micontrolador', y le pasamos un array con el $http
//y la función mi controlador



function miControlador($http){ //creamos la función de miControlador pasandole el $http(Esto sirve para que se realicen comunicaciones entre servidores a través de Ajax)
	var vm = this; //esto lo ponemos siempre
	vm.listaCuestionarios = []; //declaramos un array llamado listaUsuarios por ejemplo
	vm.cargarCuestionarios= function(){
		// creamos la función que hará la consulta y la dividimos en dos funciones principales
		var exito = function(resp){ //en esta metemos lo que hará la app si la consulta ha sido realizada correctamente
			vm.listaCuestionarios = resp.data._embedded.cuestionarios; 
		};
		var error = function(){ // si ha habido un erroe en la consulta se ejecutaria esta función 
			alert("Ha habido un error en la consulta");
		};

		$http.get("/data/cuestionarios").then(exito, error); //aquí se ponen los datos de la consulta, osea la url
		//y en el orden que aparece .then(funcionDeExito,funciónDeError)

	};
	vm.cargarCuestionarios();
	}

function miControlador2($http){ //creamos la función de miControlador pasandole el $http(Esto sirve para que se realicen comunicaciones entre servidores a través de Ajax)
	var vm2 = this; //esto lo ponemos siempre
	vm2.listaPregunta = []; //declaramos un array llamado listaUsuarios por ejemplo
	vm2.cargarPregunta= function(){
		// creamos la función que hará la consulta y la dividimos en dos funciones principales
		var exito = function(resp){ //en esta metemos lo que hará la app si la consulta ha sido realizada correctamente
			vm2.listaPregunta = resp.data._embedded.preguntas; 
		};
		var error = function(){ // si ha habido un erroe en la consulta se ejecutaria esta función 
			alert("Ha habido un error en la consulta");
		};

		$http.get("/data/preguntas").then(exito, error); //aquí se ponen los datos de la consulta, osea la url
		//y en el orden que aparece .then(funcionDeExito,funciónDeError)

	};
	vm2.cargarPregunta();
	
}