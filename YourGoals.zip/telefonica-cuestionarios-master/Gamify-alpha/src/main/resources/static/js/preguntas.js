angular
.module("app",[
	//Dependencias aquí
	])
//	creamos el controlador
	.controller("escogerpreguntas",["$http", escogerPreguntas]);

//y creamos la función del controlador
function escogerPreguntas($http){
	var x;
	x=0;
	//Función para barajar un array
	function barajar(array) {
		var currentIndex = array.length, temporaryValue, randomIndex;
		// While there remain elements to shuffle...
		while (0 !== currentIndex) {
			// Pick a remaining element...
			randomIndex = Math.floor(Math.random() * currentIndex);
			currentIndex -= 1;
			// And swap it with the current element.
			temporaryValue = array[currentIndex];
			array[currentIndex] = array[randomIndex];
			array[randomIndex] = temporaryValue;
		}
		return array;
	}

	var vm = this; //esto lo ponemos siempre
	vm.ListaPreguntas = []; //declaramos un array
	//Creamos la función que hará la consulta
	vm.CargarPreguntas= function(){
		//Función si la consulta se realiza con éxito:
		var exito = function(resp){
			vm.ListaPreguntas = resp.data._embedded.preguntas;
			vm.aciertos = 0;
			vm.errores = 0;
			vm.clase1 = "btn btn-info btn-block";
			vm.clase2 = "btn btn-info btn-block";
			vm.clase3 =" btn btn-info btn-block";
			vm.valor=false;
			vm.valorRespuestas = true;
			vm.respuestasdadas = '';
			vm.valordelinput = false;
			//Creamos la pregunta
			vm.pregunta = resp.data._embedded.preguntas[x].pregunta;
			//Creamos un array de respuestas
			vm.respuestas = [resp.data._embedded.preguntas[x].respuestaVerdadera,
				resp.data._embedded.preguntas[x].respuestaFalsaUno,
				resp.data._embedded.preguntas[x].respuestaFalsaDos];
			//Barajamos el array
			vm.respuestas = barajar(vm.respuestas);
			vm.cambiarPregunta = function(boton){
				if((vm.ListaPreguntas.length-1)==(vm.aciertos+vm.errores)){
					vm.valor=true;
					vm.valorRespuestas=false;
				}
				
				if((vm.ListaPreguntas.length)>(vm.aciertos+vm.errores)){	
					if(boton == resp.data._embedded.preguntas[x].respuestaVerdadera ){
						vm.aciertos++;
						vm.respuestasdadas=vm.respuestasdadas+resp.data._embedded.preguntas[x].id+":"+"V"+";";
					} 
					else{
						if(boton == resp.data._embedded.preguntas[x].respuestaFalsaUno){
							vm.respuestasdadas=vm.respuestasdadas+resp.data._embedded.preguntas[x].id+":"+"F1"+";";
						}
						else{
							vm.respuestasdadas=vm.respuestasdadas+resp.data._embedded.preguntas[x].id+":"+"F2"+";";
						}
						vm.errores++;
					}
					x+=1; //aquí sumamos uno al contador para cambiar a la siguiente pregunta
					vm.ListaPreguntas = resp.data._embedded.preguntas;
					//Creamos la pregunta
					vm.pregunta = resp.data._embedded.preguntas[x].pregunta;
					//Creamos un array de respuestas
					vm.respuestas = [resp.data._embedded.preguntas[x].respuestaVerdadera,
						resp.data._embedded.preguntas[x].respuestaFalsaUno,
						resp.data._embedded.preguntas[x].respuestaFalsaDos];

					vm.respuestas = barajar(vm.respuestas);
					
				
				}
			
			}

		}

		//Función si la consulta da error:
		var error = function(){ 
			alert("Ha habido un error en la consulta");
		};
		//aquí se ponen los datos de la consulta, osea la url
		//y en el orden que aparece .then(funcionDeExito,funciónDeError)
		$http.get("data/cuestionarios/1/preguntas").then(exito, error);
	};
	vm.CargarPreguntas()
}
